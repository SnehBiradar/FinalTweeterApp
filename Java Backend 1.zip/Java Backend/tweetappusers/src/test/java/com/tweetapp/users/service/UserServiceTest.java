package com.tweetapp.users.service;


import com.tweetapp.users.model.UserLoginCredential;
import com.tweetapp.users.model.Users;
import com.tweetapp.users.repository.UsersRepo;
import com.tweetapp.users.servicesImpl.EmailService;
import com.tweetapp.users.servicesImpl.JwtUtil;
import com.tweetapp.users.servicesImpl.UsersServiceImpl;
import com.tweetapp.users.utility.Constants;
import io.restassured.module.mockmvc.specification.MockMvcRequestSpecification;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class UserServiceTest {

    @InjectMocks
    private UsersServiceImpl usersService;

    @InjectMocks
    private EmailService emailService;


    @Mock
    private UserDetails userDetails;

    @Mock
    private UserLoginCredential userLoginCredential;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private UsersRepo usersRepo;





    @Mock
    private MockMvcRequestSpecification httpRequestMockMvc;


    @Test
    public void registerNewUserTest() {
      /*  Users users = new Users();u
        users.setUserName("name");
        users.setFirstName("gname");
        users.setEmail("EMAIL.COM");

        when(usersRepo.findByEmail(ArgumentMatchers.any())).thenReturn(Optional.of(users));
        when(usersRepo.save(users)).thenReturn(users);
        usersService.registerNewUser(users);*/

        Users resgistrationDetails = new Users();
        ResponseEntity response = usersService.registerNewUser(resgistrationDetails);
        assertEquals(Constants.SUCCESS,response);



    }

    @Test
    public void forgotPassword() {

        Users users = new Users();
        users.setUserName("name");
        users.setFirstName("gname");
        users.setEmail("EMAIL.COM");

        when(usersRepo.findByEmail(ArgumentMatchers.any())).thenReturn(Optional.of(users));



    }

}
