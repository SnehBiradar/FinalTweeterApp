package com.tweetapp.users.exceptions;

public class EmailIdExistsException extends  RuntimeException{
    public EmailIdExistsException(String m){super(m);}
}
