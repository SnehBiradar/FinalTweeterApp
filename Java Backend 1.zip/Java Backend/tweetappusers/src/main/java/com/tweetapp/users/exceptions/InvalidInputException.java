package com.tweetapp.users.exceptions;

public class InvalidInputException extends RuntimeException {
    public InvalidInputException(String s) {super(s);
    }
}
