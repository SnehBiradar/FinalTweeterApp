package com.tweetapp.users.utility;

public class Constants {

    public static final String USER_NOT_FOUND="User Not Found";
    public static final String ERROR="ERROR";
    public static final String RESOURSE_NOT_FOUND="RESOURSE NOT FOUND";
    public static final String USER_ID_IS_EXISTS=" Username is already exits";
    public static final String SUCCESS="SUCCESS";


    public static final String INVALID_INPUT = "Invalid Input";
    public static final String EMAIL_ID_EXITS = "Email id is already exits";
}
