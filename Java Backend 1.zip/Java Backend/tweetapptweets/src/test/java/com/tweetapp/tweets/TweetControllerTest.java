package com.tweetapp.tweets;

import com.tweetapp.tweets.controller.TweetsController;
import com.tweetapp.tweets.model.Tweet;
import com.tweetapp.tweets.services.TweetServiceImpl;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import io.restassured.module.mockmvc.response.MockMvcResponse;
import io.restassured.module.mockmvc.specification.MockMvcRequestSpecification;
import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
public class TweetControllerTest {

    @InjectMocks
    private TweetsController tweetsController;

    @Mock
    private TweetServiceImpl tweetServiceImpl;

    @Mock
    private MockMvcRequestSpecification httpRequestMockMvc;



    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(tweetsController);
        RestAssuredMockMvc.standaloneSetup(MockMvcBuilders.standaloneSetup(tweetsController));

    }


    @Test
    public void postTweetTest() {
       Tweet tweet = new Tweet();
       tweet.setTweetMsg("msg");

       String postedTweet = "new tweet";


        Mockito.when(tweetServiceImpl.postTweet(ArgumentMatchers.anyString(),tweet)).thenReturn(postedTweet);
        MockMvcResponse responseBody = httpRequestMockMvc.header("Content-Type","application/json")
                .param("userId",1)
                .body(tweet).when().post("/api/v1.0/tweets/{userId}/add");
        Assert.assertEquals(HttpStatus.SC_OK, responseBody.getStatusCode());
        assertNotNull(responseBody);
    }



    @Test
    public void getAlTweetTest() {
        MockMvcResponse responseBody = httpRequestMockMvc.header("Content-Type","application/json")
                .when().get("/api/v1.0/tweets/all");
        Assert.assertEquals(HttpStatus.SC_OK, responseBody.getStatusCode());
        Assert.assertNotNull(responseBody);
    }

}
