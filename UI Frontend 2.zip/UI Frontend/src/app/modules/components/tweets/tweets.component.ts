import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TweetDetails } from 'src/app/common/interface/tweet-details';
import { TweetService } from 'src/app/services/tweetservice/tweet.service';
import {Comment} from 'src/app/common/interface/comment';

@Component({
  selector: 'app-tweets',
  templateUrl: './tweets.component.html',
  styleUrls: ['./tweets.component.css']
})
export class TweetsComponent implements OnInit {
  @Input() tweet: TweetDetails;
  @Output() newItemEvent = new EventEmitter();
  
  isLikeed: boolean = false;
  count: number;
  tweetField = new FormControl('');
  editTweet= new FormControl('');
  userName= localStorage.getItem('userName');
  
  constructor(private tweetService: TweetService) {}
  ngOnChange() {}
 
  ngOnInit(): void {
    // console.info('Tweet info ', this.tweet);
    // this.isLikeed = this.tweet.likeBy.includes(this.userName);
    // console.info('Tweet conatins i id',
    //   this.tweet.likeBy.includes(this.userName)
    // );
    console.info('is like value', this.isLikeed);
    this.count = this.tweet.like;
    this.editTweet.setValue(this.tweet.tweetMsg);
  }

  dataDiff(tweetDate: string | number | Date) {
    let firstDate = new Date(tweetDate);
    let currentDate = new Date().toISOString();
    let newDate = new Date(currentDate.toString());

    let firstDateinSecond = firstDate.getTime() / 1000;
    let secondDateinSecond = newDate.getTime() / 1000;
    let diff = Math.abs(firstDateinSecond - secondDateinSecond);

    if (diff < 60) {
      return Math.floor(diff) + ' seconds ago';
    } else if (diff < 3600) {
      return Math.floor(diff / 60) + ' minutes ago';
    } else if (diff < 86400) {
      return Math.floor(diff / 3600) + ' hours ago';
    } else {
      return firstDate.toDateString();
    }
  }

  like() {
    this.isLikeed = !this.isLikeed;

    if (this.isLikeed) {
      this.count = this.count + 1;
    } else {
      this.count = this.count - 1;
    }
    const userName = localStorage.getItem('userName');
    this.tweetService
      .likeUnLikeTweet(userName, this.tweet.id, this.isLikeed)
      .subscribe(
        (data) => {
          console.info("Tweet reply : ",data);
        },
        (error) => {}
      );
    console.info('clicked !! ' + this.isLikeed);
  }

  replyTweet(){
    const tweetText = this.tweetField.value;
    console.info("Reply : "+tweetText);
    const userName =localStorage.getItem('userName');
    this.tweetService.replyToTweet(userName,this.tweet.id,tweetText).subscribe((data)=>{
        console.info("Tweet reply : ",data);
        this.addNewItem("new comment");
    },(errr)=>{

    })
    this.ngOnInit();
    this.tweetField.setValue('');

  }

  updateTweet(){
    const tweetText = this.editTweet.value;
    console.info("Updated tweet : "+tweetText);
    const userName =localStorage.getItem('userName');
    this.tweetService.updateTweet(userName,this.tweet.id,tweetText).subscribe((data)=>{
        console.info("Tweet reply : ",data);
        this.addNewItem("update tweet");
    },(errr)=>{

    })

    this.editTweet.setValue('');
    this.ngOnInit();
  }

  deleteTweet(){
   
    console.info(" tweet getting delete : ");
    const userName =localStorage.getItem('userName');
    this.tweetService.deleteTweet(this.tweet.id).subscribe((data)=>{
        console.info("Delete tweet : ",data);
        this.addNewItem("delete tweet");
    },(errr)=>{

    })

    
  }
  
  addNewItem(value: string) {
    this.newItemEvent.emit(value);
  }
}
