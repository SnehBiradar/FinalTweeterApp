export interface UserDetails {
      userName : string ;
      firstName: string ;
      lastName: string ;
      dateOfBirth: string ;
      email: string ;
      password: string ;
      gender: string ;
      contactNumber: string ;
}
