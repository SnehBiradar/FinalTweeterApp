export interface Comment {
      commentId :string;
      text:string;
      commentBy:string;
}
