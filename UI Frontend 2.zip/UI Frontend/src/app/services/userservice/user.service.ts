import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserDetails } from 'src/app/common/interface/user-details';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url = environment.commonUrl;
  //urltweeet = environment.commonUrlTweets; 

  tweetUrl:String ="http://shivatweetservice.us-east-2.elasticbeanstalk.com/api/v1.0/tweets";
  

  constructor(private http:HttpClient) { }

  setUserName(userName:any){
    console.log("setting username");
    localStorage.setItem("userName",userName);
  }

getUser(userName:any){ 
 console.log("get username service called "+userName);
  return this.http.post(this.url+"/getuser",userName)
}

getWelcome(){
  return this.http.get(this.tweetUrl+"/welcome",{
    withCredentials:true
  });
}

saveUserDetails(user:any){
  localStorage.setItem("user",user);
}

getAllUser(){
  return this.http.get<UserDetails[]>(this.url + '/users/all')
}

}
