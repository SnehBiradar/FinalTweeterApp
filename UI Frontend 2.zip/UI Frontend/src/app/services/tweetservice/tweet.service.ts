import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TweetDetails } from 'src/app/common/interface/tweet-details';
import { UserDetails } from 'src/app/common/interface/user-details';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TweetService {

  constructor(private http:HttpClient) { }

  //url = environment.commonUrlTweets;

  tweetUrl:String ="http://shivatweetservice.us-east-2.elasticbeanstalk.com/api/v1.0/tweets";

  postTweet(userName: any,payload: any){
    return this.http.post<String>(this.tweetUrl + "/"+userName +'/add', payload, {
      responseType: 'text' as 'json'
    });
  }

  getAllTweet(){
    return this.http.get<TweetDetails>(this.tweetUrl + '/all');
  }

  likeUnLikeTweet(userName: string | null,tweetId: string,type: string | boolean){
    return this.http.post<TweetDetails>(this.tweetUrl + '/like/' +userName +'/'+tweetId + '/' + type,null);
  }

  getAllTweetByUserId(userName: any){
    return this.http.get<TweetDetails[]>(this.tweetUrl +'/'+userName);

  }
  replyToTweet(userName: string | null,tweetId: string,replyMsg: any){
    return this.http.post<any>(this.tweetUrl + '/reply/' +userName +'/'+tweetId , replyMsg);
  }

  updateTweet(userName: string | null,tweetId: string,replyMsg: any){
    return this.http.put<UserDetails>(this.tweetUrl + '/update/' +userName +'/'+tweetId , replyMsg);
  }

  deleteTweet(tweetId: string){
    return this.http.delete<any>(this.tweetUrl + '/delete' +'/'+tweetId);  
  }
}
