export const environment = {
  production: true,
  commonUrl : 'http://shivajrfse.us-east-2.elasticbeanstalk.com/api/v1.0/tweets',

};
